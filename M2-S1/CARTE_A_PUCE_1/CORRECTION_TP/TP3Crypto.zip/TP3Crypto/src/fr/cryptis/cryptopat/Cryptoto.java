/**
 * 
 */
package fr.cryptis.cryptopat;

import javacard.framework.Applet;
import javacard.framework.ISOException;
import javacard.framework.ISO7816;
import javacard.framework.APDU;
import javacard.framework.Util;
import javacard.security.DESKey;
import javacard.security.KeyBuilder;
import javacard.security.KeyPair;
import javacard.security.PrivateKey;
import javacard.security.RSAPrivateCrtKey;
import javacard.security.RSAPublicKey;
import javacard.security.RandomData;
import javacard.security.Signature;
import javacardx.crypto.Cipher;

/**
 * @author Damien Sauveron
 *
 */
public class Cryptoto extends Applet implements ISO7816{
	
	final static byte SET_KEY = 0x10;
	final static byte GET_CHALLENGE = 0x20;
	final static byte SET_CHALLENGE = 0x30;
	final static byte VERIFY_CRYPTO = 0x40;

	final static short RNG_SIZE = 0x08;
	
	RandomData rng;
	KeyPair kp;
	RSAPrivateCrtKey prRSACRTkey;
	RSAPublicKey pubRSAkey;
	Signature sgn;
	RSAPublicKey peerpubRSAkey;
	DESKey dk;
	Cipher cipher;
	byte[] monAlea;
	
	public Cryptoto() {
		rng = RandomData.getInstance(RandomData.ALG_PSEUDO_RANDOM);
		kp = new KeyPair(KeyPair.ALG_RSA_CRT, KeyBuilder.LENGTH_RSA_512);
		kp.genKeyPair();
		prRSACRTkey = (RSAPrivateCrtKey) kp.getPrivate();
		pubRSAkey = (RSAPublicKey) kp.getPublic();
		sgn = Signature.getInstance(Signature.ALG_RSA_SHA_PKCS1, false);
		peerpubRSAkey = (RSAPublicKey) KeyBuilder.buildKey(KeyBuilder.TYPE_RSA_PUBLIC, KeyBuilder.LENGTH_RSA_512, false);
		dk = (DESKey) KeyBuilder.buildKey(KeyBuilder.TYPE_DES, KeyBuilder.LENGTH_DES3_3KEY, false);
		cipher = Cipher.getInstance(Cipher.ALG_DES_CBC_NOPAD, false);
		monAlea = new byte[RNG_SIZE];
	}
	
	public static void install(byte[] bArray, short bOffset, byte bLength) {
		// GP-compliant JavaCard applet registration
		new Cryptoto().register(bArray, (short) (bOffset + 1), bArray[bOffset]);
	}

	public void process(APDU apdu) {
		// Good practice: Return 9000 on SELECT
		if (selectingApplet()) {
			return;
		}

		byte[] buf = apdu.getBuffer();
		short of=0;
		short len;
		
		switch (buf[ISO7816.OFFSET_INS]) {
		case SET_KEY:
			len = apdu.setIncomingAndReceive();
			dk.setKey(buf, OFFSET_CDATA);
			break;
		case GET_CHALLENGE:
			of = 0;
			rng.generateData(buf, of, RNG_SIZE);
			Util.arrayCopyNonAtomic(buf, of, monAlea, of, RNG_SIZE);
			of+=RNG_SIZE;
			of += pubRSAkey.getExponent(buf, of);
			of += pubRSAkey.getModulus(buf, of);
			
			sgn.init(prRSACRTkey, Signature.MODE_SIGN);
			of += sgn.sign(buf, (short)0, of, buf, of);
			
			apdu.setOutgoingAndSend((short)0, of);
			break;
		case SET_CHALLENGE:
			len = apdu.setIncomingAndReceive();
			of = ISO7816.OFFSET_CDATA+RNG_SIZE;
			peerpubRSAkey.setExponent(buf, of, (short)4);
			of += 4;
			peerpubRSAkey.setModulus(buf, of, (short)(KeyBuilder.LENGTH_RSA_512>>3));
			of += (short)(KeyBuilder.LENGTH_RSA_512>>3);

			sgn.init(peerpubRSAkey, Signature.MODE_VERIFY);
			if (!sgn.verify(buf, (short)ISO7816.OFFSET_CDATA, (short)(of-ISO7816.OFFSET_CDATA), buf, of, (short)(len-(of-ISO7816.OFFSET_CDATA))))
				ISOException.throwIt(ISO7816.SW_CONDITIONS_NOT_SATISFIED);
			
			of = 0;
			cipher.init(dk, Cipher.MODE_ENCRYPT);
			of += cipher.doFinal(buf, OFFSET_CDATA, RNG_SIZE, buf, of);

			sgn.init(prRSACRTkey, Signature.MODE_SIGN);
			of += sgn.sign(buf, (short)0, of, buf, of);
			
			apdu.setOutgoingAndSend((short)0, of);
			
			break;
		case VERIFY_CRYPTO:
			len = apdu.setIncomingAndReceive();
			of = ISO7816.OFFSET_CDATA+RNG_SIZE;
			
			sgn.init(peerpubRSAkey, Signature.MODE_VERIFY);
			if (!sgn.verify(buf, (short)ISO7816.OFFSET_CDATA, (short)(of-ISO7816.OFFSET_CDATA), buf, of, (short)(len-(of-ISO7816.OFFSET_CDATA))))
				ISOException.throwIt(ISO7816.SW_CONDITIONS_NOT_SATISFIED);

			of = OFFSET_CDATA;
			cipher.init(dk, Cipher.MODE_DECRYPT);
			cipher.doFinal(buf, of, RNG_SIZE, buf, of);
			
			if(Util.arrayCompare(buf, of, monAlea, (short)0, RNG_SIZE)!=0)
				ISOException.throwIt(ISO7816.SW_SECURITY_STATUS_NOT_SATISFIED);
			
			break;
		default:
			// good practice: If you don't know the INStruction, say so:
			ISOException.throwIt(ISO7816.SW_INS_NOT_SUPPORTED);
		}
	}
}